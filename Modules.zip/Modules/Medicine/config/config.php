<?php

return [
    'name' => 'Medicine',
];
