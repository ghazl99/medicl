<x-offer::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('offer.name') !!}</p>
</x-offer::layouts.master>
