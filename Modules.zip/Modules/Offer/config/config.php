<?php

return [
    'name' => 'Offer',
];
