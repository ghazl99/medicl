<?php

namespace Modules\Offer\Database\Seeders;

use Illuminate\Database\Seeder;

class OfferDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
