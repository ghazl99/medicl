<?php

namespace Modules\Offer\Services;

class OfferService
{
    public function handle() {}
}
