<?php

namespace Modules\Offer\Repositories;

class OfferRepository
{
    public function handle() {}
}
