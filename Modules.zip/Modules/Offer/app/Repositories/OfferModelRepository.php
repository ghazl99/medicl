<?php

namespace Modules\Offer\Repositories;

class OfferModelRepository
{
    public function handle() {}
}
