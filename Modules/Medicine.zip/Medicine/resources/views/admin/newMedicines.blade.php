{{-- resources/views/medicines/new.blade.php --}}
@extends('core::components.layouts.master')

@section('content')
<div class="container">
    <h3 class="mb-4">الأدوية الجديدة</h3>

    @if ($medicines->count())
        <div class="table-responsive">
            <table class="table table-bordered text-center">
                <thead>
                    <tr>
                        <th>الاسم</th>
                        <th>الصنف</th>
                        <th>من تاريخ</th>
                        <th>إلى تاريخ</th>
                        <th>الحالة</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($medicines as $medicine)
                        <tr>
                            <td>{{ $medicine->type }}</td>
                            <td>{{ $medicine->category->name ?? '-' }}</td>
                            <td>{{ $medicine->new_start_date }}</td>
                            <td>{{ $medicine->new_end_date }}</td>
                            <td>
                                <span class="badge bg-success">جديد</span>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        {{ $medicines->links() }} {{-- pagination --}}
    @else
        <p class="text-muted">لا توجد أدوية جديدة حالياً.</p>
    @endif
</div>
@endsection
