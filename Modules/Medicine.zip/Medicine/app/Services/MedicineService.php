<?php

namespace Modules\Medicine\Services;

use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Modules\Medicine\Models\Medicine;
use Modules\Medicine\Repositories\MedicineRepositoryInterface;

class MedicineService
{
    protected MedicineRepositoryInterface $medicineRepository;

    public function __construct(MedicineRepositoryInterface $medicineRepository)
    {
        $this->medicineRepository = $medicineRepository;
    }

    /**
     * Get all medicines (optionally filtered by keyword).
     */
    public function getAllMedicines(?string $keyword = null): LengthAwarePaginator
    {
        return $this->medicineRepository->index($keyword);
    }

    /**
     * Get medicines for a specific supplier (optionally filtered).
     */
    public function getAllMedicinesSupplier(?string $keyword, $user): LengthAwarePaginator
    {
        return $this->medicineRepository->getMedicinesBySupplier($keyword, $user);
    }

    /**
     * Find a medicine by ID.
     */
    public function getMedicineById(int $id): ?Medicine
    {
        return $this->medicineRepository->findById($id);
    }

    /**
     * Create a new medicine and assign it to supplier if applicable.
     */
    public function createMedicine(array $data, $user): Medicine
    {
        return DB::transaction(function () use ($data, $user) {
            $image = $data['image'] ?? null;
            unset($data['image']);

            $medicine = $this->medicineRepository->store($data);

            if (! $user) {
                throw new \Exception('المستخدم غير موجود أو غير مسجل الدخول.');
            }

            if ($user->hasRole('مورد')) {
                $user->medicines()->attach($medicine->id);
            }

            if ($image) {
                $medicine
                    ->addMedia($image)
                    ->toMediaCollection('medicine_images', 'private_media');
            }

            return $medicine;
        });
    }

    /**
     * Assign a list of medicines to a supplier.
     */
    public function assignMedicinesToSupplier(array $medicineIds, int $supplierId): void
    {
        $this->medicineRepository->syncMedicinesToSupplier($medicineIds, $supplierId);
    }

    /**
     * Update an existing medicine.
     */
    public function updateMedicine(Medicine $medicine, array $data): Medicine
    {
        return $this->medicineRepository->update($medicine, $data);
    }

    /**
     * Delete a medicine by ID.
     */
    public function deleteMedicine(int $id): ?bool
    {
        return $this->medicineRepository->delete($id);
    }

    /**
     * Toggle availability of a medicine for a specific supplier.
     */
    public function toggleAvailability(int $medicineId, int $supplierId): bool
    {
        $pivot = $this->medicineRepository->findPivotByMedicineAndSupplier($medicineId, $supplierId);

        if (! $pivot) {
            throw new \Exception('Medicine is not linked with the supplier.');
        }

        $currentStatus = (bool) $pivot->pivot->is_available;
        $this->medicineRepository->updatePivotAvailability($medicineId, $supplierId, ! $currentStatus);

        return ! $currentStatus;
    }

    /**
     * Update notes on the pivot table between medicine and supplier.
     */
    public function updateNoteOnPivot(int $pivotId, ?string $notes): bool
    {
        return $this->medicineRepository->updateNoteOnPivot($pivotId, $notes);
    }

    /**
     * Update the new status and the start/end dates of a medicine.
     */
    public function updateNewStatus(Medicine $medicine, bool $isNew, string $startDate, string $endDate): Medicine
    {
        return $this->medicineRepository->updateNewStatus($medicine, $isNew, $startDate, $endDate);
    }

     public function getNewMedicines()
    {
        return $this->medicineRepository->getNewMedicines();
    }
}
